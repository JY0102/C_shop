﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RiotSearchInfo_Ver2
{
    public class MatchContext : DbContext
    {
        private const string server_name = "DESKTOP-V3OB23V\\SQLEXPRESS";
        private const string db_name = "WB41";
        private const string sql_id = "aaa";
        private const string sql_pw = "1234";

        public MatchContext()
            : base($"Server={server_name};Database={db_name};User Id={sql_id};Password={sql_pw};TrustServerCertificate=True;")
        {
            // 지연 로딩 비활성화 (성능 향상)
            this.Configuration.LazyLoadingEnabled = false;
            // 프록시 생성 비활성화 (직렬화 문제 방지)
            this.Configuration.ProxyCreationEnabled = false;
        }

        public DbSet<Match> Matches { get; set; }

        // Entity Framework 모델 구성
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Match>().ToTable("Matches");
            modelBuilder.Entity<Participant>().ToTable("Participants");
            modelBuilder.Entity<Team>().ToTable("Teams");
            modelBuilder.Entity<Tier>().ToTable("Tiers");
        }
    }
}