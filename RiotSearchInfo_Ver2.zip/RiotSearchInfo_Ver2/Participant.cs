﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace RiotSearchInfo_Ver2
{

    [DataContract]
    public class Participant
    {
        #region 데이터 테이블 PK , FK 설정
        public string MatchId { get; set; }

        [ForeignKey("MatchId")]
        public virtual Match Match { get; set; }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ParticipantId { get; set; }
        #endregion

        #region 팀 정보

        [DataMember] private string teamName;

        [DataMember]
        public string teamid
        {
            get => teamName;
            set
            {
                if (value == null)
                {
                    teamName = "";
                    return;
                }

                if (value == "100")
                    teamName = "블루팀";
                else if (value == "200")
                    teamName = "레드팀";
                else
                    teamName = value;
            }
        }

        #endregion

        #region 승리 여부
        [DataMember] public bool win { get; set; }
        #endregion

        #region 챔피언
        [DataMember] public string championName { get; set; }

        //이미지
        [DataMember] public byte[] championImg { get; set; }
        #endregion

        #region 닉네임
        [DataMember] public string GameName { get => $"{riotIdGameName}#{riotIdTagline}"; }

        [DataMember] public string riotIdGameName { get; set; }

        [DataMember] public string riotIdTagline { get; set; }

        #endregion

        #region PUUID
        [DataMember] public string puuid { get; set; }
        #endregion

        #region 스펠

        [DataMember] public string summoner1Id { get; set; }

        [DataMember] public string summoner2Id { get; set; }

        // 이미지

        [DataMember] public byte[] summoner1Id_Img { get; set; }

        [DataMember] public byte[] summoner2Id_Img { get; set; }

        #endregion

        #region 챔피언 레벨
        [DataMember] public string champLevel { get; set; }
        #endregion

        #region 아이템

        [DataMember] public string item0 { get; set; }

        [DataMember] public string item1 { get; set; }

        [DataMember] public string item2 { get; set; }

        [DataMember] public string item3 { get; set; }

        [DataMember] public string item4 { get; set; }

        [DataMember] public string item5 { get; set; }

        [DataMember] public string item6 { get; set; }

        // 이미지

        [DataMember] public byte[] item0_Img { get; set; }

        [DataMember] public byte[] item1_Img { get; set; }

        [DataMember] public byte[] item2_Img { get; set; }

        [DataMember] public byte[] item3_Img { get; set; }

        [DataMember] public byte[] item4_Img { get; set; }

        [DataMember] public byte[] item5_Img { get; set; }
        [DataMember] public byte[] item6_Img { get; set; }

        #endregion

        #region 미니언 개수

        [DataMember] private string _totalMinionsKilled { get; set; }


        [DataMember]
        public string totalMinionsKilled
        {
            get => "CS:" + _totalMinionsKilled;
            set
            {
                if (value.IndexOf("CS") == 0)
                {
                    string[] sp = value.Split(':');

                    _totalMinionsKilled = sp[1];
                }
                else
                    _totalMinionsKilled = value;
            }
        }

        #endregion

        #region 골드량

        [DataMember] private string _goldEarned { get; set; }

        [DataMember]
        public string goldEarned
        {
            get => "골드 : " + _goldEarned;
            set
            {
                if (int.TryParse(value, out int temp))
                    _goldEarned = temp.ToString("N0");
                else if (value != null)
                {
                    if (value.IndexOf("골드") == 0)
                    {
                        string[] sp = value.Split(':');

                        _goldEarned = sp[1];
                    }
                    else
                        _goldEarned = value;
                }
            }
        }

        #endregion

        #region 딜량 , 받은 피해량
        [DataMember] public string totalDamageDealtToChampions { get; set; }
        [DataMember] public string totalDamageTaken { get; set; }

        #endregion

        #region KDA 관련

        [DataMember]
        private Dictionary<string, object> temp = null;

        [DataMember]
        public Dictionary<string, object> challenges
        {
            get => temp;

            set
            {
                if (value?.ContainsKey("kda") == true &&
                    double.TryParse(value["kda"].ToString(), out double temp))
                {
                    kda = temp.ToString("F2");
                    value.Clear();
                }
            }
        }

        [DataMember] public string kda { get; set; }

        [DataMember] public string K_D_A { get => $"{kills} / {deaths} / {assists}"; }

        [DataMember] public string kills { get; set; }

        [DataMember] public string deaths { get; set; }

        [DataMember] public string assists { get; set; }

        [DataMember] public string killPercent { get; set; }

        #endregion

        #region 룬
        [DataMember] private object temp123 = null;

        [DataMember]
        public object perks
        {
            get => temp123;
            set => SetRune(value);
        }

        [DataMember] public string primaryRune { get; set; }
        [DataMember] public byte[] primaryRune_Img { get; set; }
        [DataMember] public string subRune { get; set; }
        [DataMember] public byte[] subRune_Img { get; set; }

        public void SetRune(object perk)
        {
            try
            {
                var _perks = JsonConvert.DeserializeObject<Dictionary<string, object>>(perk.ToString());
                var styles = JsonConvert.DeserializeObject<List<Dictionary<string, object>>>(_perks["styles"].ToString());

                // 주룬
                var primaryStyle = JsonConvert.DeserializeObject<List<Dictionary<string, object>>>(styles[0]["selections"].ToString());
                primaryRune = primaryStyle[0]["perk"].ToString();

                // 부룬 - 기존 값 초기화
                var subStyle = JsonConvert.DeserializeObject<List<Dictionary<string, object>>>(styles[1]["selections"].ToString());
                subRune = subStyle[0]["perk"].ToString();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"룬 설정 오류: {ex.Message}");
                primaryRune = "Unknown";
                subRune = "Unknown";
            }
        }

        #endregion

        #region 티어
        [DataMember] public List<Tier> Tiers { get; set; } = null;

        [DataMember]
        public Tier SoloTiers
        {
            get
            {
                if (Tiers == null) return null;

                foreach (var tier in Tiers)
                {
                    if (tier.queueType == "솔로랭크")
                        return tier;
                }
                return null;
            }
        }

        [DataMember]
        public Tier FlexTiers
        {
            get
            {
                if (Tiers == null) return null;

                foreach (var tier in Tiers)
                {
                    if (tier.queueType == "자유랭크")
                        return tier;
                }
                return null;
            }
        }
        #endregion
    }
}
