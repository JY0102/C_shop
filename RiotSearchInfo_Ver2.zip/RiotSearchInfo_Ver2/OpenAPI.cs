﻿using Newtonsoft.Json;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Data.Entity;

namespace RiotSearchInfo_Ver2
{
    public class OpenAPI : RiotTable
    {
        public List<Match> Matches = new List<Match>();
        private string API_KEY = string.Empty;
        public string My_Puuid = string.Empty;
        private static readonly HttpClient httpClient = new HttpClient();

        public void AddKey(string key)
        {
            API_KEY = key;
            // Accept-Language
            if (httpClient.DefaultRequestHeaders.Contains("Accept-Language"))
                httpClient.DefaultRequestHeaders.Remove("Accept-Language");
            httpClient.DefaultRequestHeaders.Add("Accept-Language", "ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7");

            // Accept-Charset
            if (httpClient.DefaultRequestHeaders.Contains("Accept-Charset"))
                httpClient.DefaultRequestHeaders.Remove("Accept-Charset");
            httpClient.DefaultRequestHeaders.Add("Accept-Charset", "utf-8");

            // X-Riot-Token
            if (httpClient.DefaultRequestHeaders.Contains("X-Riot-Token"))
                httpClient.DefaultRequestHeaders.Remove("X-Riot-Token");
            httpClient.DefaultRequestHeaders.Add("X-Riot-Token", API_KEY);
        }

        public async Task<List<Match>> SearchAsync(string gameName, string type, int count)
        {
            try
            {
                string[] sp = gameName.Split('#');
                if (sp.Length != 2 || string.IsNullOrEmpty(sp[0]) || string.IsNullOrEmpty(sp[1]))
                {
                    throw new ArgumentException("닉네임과 태그가 올바르지 않습니다.");
                }

                // PUUID 조회
                string puuid = await SearchPuuidAsync(sp[0], sp[1]);
                if (string.IsNullOrEmpty(puuid))
                {
                    throw new Exception("사용자를 찾을 수 없습니다.");
                }

                // 매치 ID 조회
                var matchIds = await SearchMatchAsync(puuid, type, count);
                if (matchIds == null || matchIds.Count == 0)
                {
                    return new List<Match>();
                }

                foreach (var matchId in matchIds)
                {
                    try
                    {
                        Console.WriteLine($"매치 처리 중: {matchId}");

                        Match existingMatch = null;
                        using (var context = new MatchContext())
                        {
                            existingMatch = context.Matches
                                .Include("participants")
                                .Include("participants.Tiers")
                                .Include("teams")
                                .FirstOrDefault(m => m.matchId == matchId);

                            if (existingMatch != null)
                                continue;
                        }

                        Console.WriteLine($"새 매치 데이터 가져오기: {matchId}");
                        var info = await MatchDataAsync(matchId);

                        var matchinfo = Make_Match(info["info"]);

                        // 참가자 티어 정보 가져오기
                        if (matchinfo.participants != null)
                        {
                            foreach (var participant in matchinfo.participants)
                            {
                                try
                                {
                                    if (!string.IsNullOrEmpty(participant.puuid))
                                    {
                                        participant.Tiers = await GetTierAsync(participant.puuid);
                                    }
                                    else
                                    {
                                        participant.Tiers = new List<Tier>();
                                    }
                                }
                                catch (Exception ex)
                                {
                                    Console.WriteLine($"티어 정보 가져오기 실패 ({participant?.riotIdGameName}): {ex.Message}");
                                    participant.Tiers = new List<Tier>();
                                }
                            }
                        }

                        matchinfo.GameNickName = gameName;
                        matchinfo.matchId = matchId;
                        matchinfo.SetMyPart(puuid);

                        Matches.Add(matchinfo);

                        SetImg(matchinfo);
                        using (var context = new MatchContext())
                        {
                            context.Matches.Add(matchinfo);
                            context.SaveChanges();
                        }
                    }
                    catch (Exception matchEx)
                    {
                        Console.WriteLine($"매치 처리 중 오류 ({matchId}): {matchEx.Message}");
                        Console.WriteLine($"스택 트레이스: {matchEx.StackTrace}");
                    }
                }

                return Matches;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"SearchAsync 전체 오류: {ex.Message}");
                Console.WriteLine($"스택 트레이스: {ex.StackTrace}");
                throw new Exception($"검색 오류 발생: {ex.Message}");
            }
        }

        public List<Match> Search(string gameName, string type, int count)
        {
            return SearchAsync(gameName, type, count).Result;
        }

        #region Async API Request
        public async Task<string> SearchPuuidAsync(string gameName, string tagLine)
        {
            try
            {
                string url = $"https://asia.api.riotgames.com/riot/account/v1/accounts/by-riot-id/{gameName}/{tagLine}";

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                request.Headers.Add("Accept-Language", "ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7");
                request.Headers.Add("Accept-Charset", "application/x-www-form-urlencoded; charset=UTF-8");
                request.Headers.Add("X-Riot-Token", API_KEY);

                using (var response = await request.GetResponseAsync() as HttpWebResponse)
                {
                    if (response.StatusCode != HttpStatusCode.OK)
                    {
                        Console.WriteLine($"PUUID 검색 실패: {response.StatusCode}");
                        return null;
                    }

                    using (var stream = response.GetResponseStream())
                    using (var reader = new StreamReader(stream))
                    {
                        var responseContent = await reader.ReadToEndAsync();

                        if (string.IsNullOrEmpty(responseContent))
                        {
                            return null;
                        }

                        var temp = JsonConvert.DeserializeObject<Dictionary<string, object>>(responseContent);
                        return temp?.ContainsKey("puuid") == true ? temp["puuid"].ToString() : null;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"PUUID 검색 오류: {ex.Message}");
                return null;
            }
        }

        private async Task<List<string>> SearchMatchAsync(string puuid, string type, int count)
        {
            try
            {
                if (string.IsNullOrEmpty(puuid))
                {
                    return new List<string>();
                }

                string url = $"https://asia.api.riotgames.com/lol/match/v5/matches/by-puuid/{puuid}/ids" +
                            $"?type={type}&start=0&count={count}&api_key={API_KEY}";

                string response = await GetApiResponseAsync(url);

                if (string.IsNullOrEmpty(response))
                    return new List<string>();

                var matchIds = JsonConvert.DeserializeObject<List<string>>(response);
                return matchIds ?? new List<string>();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"매치 검색 오류: {ex.Message}");
                return new List<string>();
            }
        }

        private async Task<Dictionary<string, object>> MatchDataAsync(string matchid)
        {
            try
            {
                if (string.IsNullOrEmpty(matchid))
                    return null;

                string url = $"https://asia.api.riotgames.com/lol/match/v5/matches/{matchid}?api_key={API_KEY}";
                string response = await GetApiResponseAsync(url);

                if (string.IsNullOrEmpty(response))
                {
                    return null;
                }

                var matchData = JsonConvert.DeserializeObject<Dictionary<string, object>>(response);
                return matchData;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"매치 데이터 가져오기 오류: {ex.Message}");
                return null;
            }
        }

        private async Task<List<Tier>> GetTierAsync(string puuid)
        {
            try
            {
                if (string.IsNullOrEmpty(puuid))
                {
                    return new List<Tier>();
                }

                string url = $"https://kr.api.riotgames.com/lol/league/v4/entries/by-puuid/{puuid}";
                string response = await GetApiResponseAsync(url);

                if (string.IsNullOrEmpty(response))
                {
                    return new List<Tier>();
                }

                var tiers = JsonConvert.DeserializeObject<List<Tier>>(response) ?? new List<Tier>();
                return tiers;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"티어 정보 가져오기 오류: {ex.Message}");
                return new List<Tier>();
            }
        }
        #endregion

        #region Helper Methods
        private async Task<string> GetApiResponseAsync(string url)
        {
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                request.Headers.Add("X-Riot-Token", API_KEY);

                using (var response = await request.GetResponseAsync() as HttpWebResponse)
                {
                    if (response.StatusCode != HttpStatusCode.OK)
                        throw new Exception($"API 요청 실패: {response.StatusCode}");

                    using (var stream = response.GetResponseStream())
                    using (var reader = new StreamReader(stream))
                    {
                        return await reader.ReadToEndAsync();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"API 응답 가져오기 오류: {ex.Message}");
                throw;
            }
        }

        private Match Make_Match(object info)
        {
            try
            {
                if (info == null) return null;
                return JsonConvert.DeserializeObject<Match>(info.ToString());
            }
            catch (Exception ex)
            {
                Console.WriteLine($"매치 객체 생성 오류: {ex.Message}");
                return null;
            }
        }

        private void SetImg(Match matchinfo)
        {
            foreach (var participant in matchinfo.participants)
            {
                // 챔피언 이미지
                participant.championImg = GetChampionByte(participant.championName);

                // 스펠 이미지
                participant.summoner1Id_Img = GetSpellByte(participant.summoner1Id);
                participant.summoner2Id_Img = GetSpellByte(participant.summoner2Id);

                // 아이템 이미지
                participant.item0_Img = GetItemByte(participant.item0);
                participant.item1_Img = GetItemByte(participant.item1);
                participant.item2_Img = GetItemByte(participant.item2);
                participant.item3_Img = GetItemByte(participant.item3);
                participant.item4_Img = GetItemByte(participant.item4);
                participant.item5_Img = GetItemByte(participant.item5);
                participant.item6_Img = GetItemByte(participant.item6);

                // 룬 이미지
                participant.primaryRune_Img = GetRuneByte(participant.primaryRune);
                participant.subRune_Img = GetRuneByte(participant.subRune);
            }
        }
        #endregion
    }
}