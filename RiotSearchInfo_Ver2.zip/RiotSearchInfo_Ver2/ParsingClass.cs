﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace RiotSearchInfo_Ver2
{
    #region Spell Parsing Classes
    public class SpellData
    {
        [JsonProperty("data")]
        public Dictionary<string, Spell> Data { get; set; } = new Dictionary<string, Spell>();
    }

    public class Spell
    {
        [JsonProperty("key")]
        public string key { get; set; }
    }
    #endregion

    #region Item Parsing Classes
    public class ItemData
    {
        [JsonProperty("data")]
        public Dictionary<string, Item> Data { get; set; } = new Dictionary<string, Item>();
    }

    public class Item
    {
        public string Id { get; set; }

        [JsonProperty("image")]
        public Dictionary<string, string> image { get; set; } = new Dictionary<string, string>();

        public string img
        {
            get => image?.ContainsKey("full") == true ? image["full"] : string.Empty;
        }
    }
    #endregion

    #region Rune Parsing Classes
    public class RuneData
    {
        [JsonProperty("id")]
        public string id { get; set; }

        [JsonProperty("icon")]
        public string icon { get; set; }

        [JsonProperty("slots")]
        public List<Dictionary<string, List<Rune>>> slots { get; set; } = new List<Dictionary<string, List<Rune>>>();
    }

    public class Rune
    {
        [JsonProperty("id")]
        public string id { get; set; }

        [JsonProperty("icon")]
        public string icon { get; set; }
    }
    #endregion

    #region Champion Parsing Classes

    public class Champion
    {
        [JsonProperty("data")]
        public Dictionary<string, object> Data { get; set; } = new Dictionary<string, object>();
    }
    #endregion
}
