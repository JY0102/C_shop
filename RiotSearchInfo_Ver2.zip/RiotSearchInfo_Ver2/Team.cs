﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace RiotSearchInfo_Ver2
{
    [DataContract]
    public class Team
    {
        #region 데이터 테이블 PK , FK 설정
        public string MatchId { get; set; }

        [ForeignKey("MatchId")]
        public virtual Match Match { get; set; }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int TeamId { get; set; }
        #endregion

        [DataMember]
        private Dictionary<string, Dictionary<string, string>> temp = null;

        [DataMember]
        public Dictionary<string, Dictionary<string, string>> feats
        {
            get => temp;

            set
            {
                if (value?.ContainsKey("FIRST_BLOOD") == true &&
                    value["FIRST_BLOOD"]?.ContainsKey("featState") == true &&
                    value["FIRST_BLOOD"]["featState"] == "3")
                {
                    FirstBlood = true;
                    value.Clear();
                }
            }
        }

        #region 퍼블
        [DataMember] public bool FirstBlood { get; set; } = false;
        #endregion

        #region 오브젝트들
        [DataMember]
        private Dictionary<string, Dictionary<string, string>> temp456 = null;

        [DataMember]
        public Dictionary<string, Dictionary<string, string>> objectives
        {
            get => temp456;

            set
            {
                SetObjectives(value);
            }
        }

        private void SetObjectives(Dictionary<string, Dictionary<string, string>> objs)
        {
            if (objs == null) return;

            foreach (var obj in objs)
            {
                if (!obj.Value.ContainsKey("kills")) continue;

                switch (obj.Key)
                {
                    case "atakhan": atakhan = obj.Value["kills"]; break;
                    case "baron": baron = obj.Value["kills"]; break;
                    case "champion": champion = obj.Value["kills"]; break;
                    case "dragon": dragon = obj.Value["kills"]; break;
                    case "horde": horde = obj.Value["kills"]; break;
                    case "riftHerald": riftHerald = obj.Value["kills"]; break;
                    case "inhibitor": inhibitor = obj.Value["kills"]; break;
                    case "tower": tower = obj.Value["kills"]; break;
                }
            }
        }

        // 프로퍼티
        [DataMember] public string atakhan { get; set; }

        [DataMember] public string baron { get; set; }

        [DataMember] public string champion { get; set; }

        [DataMember] public string dragon { get; set; }

        [DataMember] public string horde { get; set; }

        [DataMember] public string riftHerald { get; set; }

        [DataMember] public string inhibitor { get; set; }

        [DataMember] public string tower { get; set; }
        #endregion
    }
}
