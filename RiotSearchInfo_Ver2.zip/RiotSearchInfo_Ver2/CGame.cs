﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.ServiceModel.Web;
using System.Data.Entity;
using System.IO;
using Newtonsoft.Json;
using System.Text;
using System.Text.RegularExpressions;

namespace RiotSearchInfo_Ver2
{
    internal class CGame : IGame
    {
        private readonly OpenAPI _openAPI;
        private const string API_KEY = "RGAPI-eac9e8d5-f791-43f6-8efc-f2633f1a1e7a";

        public CGame()
        {
            try
            {
                Console.WriteLine("CGame 초기화 시작...");
                _openAPI = new OpenAPI();
                _openAPI.AddKey(API_KEY);
                Console.WriteLine("CGame 초기화 완료");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"CGame 초기화 실패: {ex.Message}");
                throw new Exception($"CGame 초기화 중 오류 발생: {ex.Message}");
            }
        }

        #region Public Methods - POST (데이터 불러오기)
        public void SearchGameInfo(SearchGameInfoRequest request)
        {
            try
            {
                Console.WriteLine("SearchGameInfo 호출됨");

                if (request == null)
                {
                    Console.WriteLine("Request is null");
                }

                string gamenickname = request.gamenickname;
                string gametype = request.gametype;
                string gamecount = request.gamecount;

                Console.WriteLine($"요청 정보 - 닉네임: {gamenickname}, 게임타입: {gametype}, 게임수: {gamecount}");

                if (string.IsNullOrEmpty(gamenickname))
                {
                    Console.WriteLine("Game nickname is empty");
                }

                if (!gamenickname.Contains("#"))
                {
                    Console.WriteLine("Invalid nickname format");
                }

                int count = int.Parse(gamecount); 
                if (!string.IsNullOrEmpty(gamecount))
                {
                    if (int.TryParse(gamecount, out int parsedCount))
                    {
                        count = Math.Max(1, Math.Min(parsedCount, 10));
                        Console.WriteLine($"요청된 게임 수: {parsedCount}, 실제 조회 수: {count}");
                    }
                    else
                    {
                        Console.WriteLine($"잘못된 게임 수 형식: {gamecount}, 기본값 사용");
                    }
                }

                #region API를 통한 Match Search 및 DB 저장
                Console.WriteLine($"매치 검색 시작... (최근 {count}게임)");
                List<Match> matches = _openAPI.Search(gamenickname, gametype, count);

                if (matches == null || matches.Count == 0)
                {
                    Console.WriteLine("매치를 찾을 수 없음");
                }

                Console.WriteLine($"매치 검색 완료: {count}개 찾음");
                #endregion
            }
            catch (Exception ex)
            {
                Console.WriteLine($"SearchGameInfo 오류: {ex.Message}");
                Console.WriteLine($"스택 트레이스: {ex.StackTrace}");
            }
        }
        #endregion

        #region Public Methods - GET (데이터 순회 후 반환)
        public GameListResponse GetGameHistory(string gamenickname, string gametype, string gamecount)
        {
            try
            {
                Console.WriteLine("GetGameHistory 호출됨");

                if (string.IsNullOrEmpty(gamenickname))
                {
                    Console.WriteLine("Game nickname is empty");
                }

                // URL 디코딩 추가
                gamenickname = Uri.UnescapeDataString(gamenickname);
                Console.WriteLine($"디코딩된 닉네임: {gamenickname}");

                // 닉네임 형식 검증
                if (!gamenickname.Contains("#"))
                {
                    Console.WriteLine("Invalid nickname format");
                }

                int count = int.Parse(gamecount);
                if (!string.IsNullOrEmpty(gamecount))
                {
                    if (int.TryParse(gamecount, out int parsedCount))
                    {
                        count = Math.Max(1, Math.Min(parsedCount, 10));
                        Console.WriteLine($"요청된 게임 수: {parsedCount}, 실제 조회 수: {count}");
                    }
                    else
                    {
                        Console.WriteLine($"잘못된 게임 수 형식: {gamecount}, 기본값 사용");
                    }
                }

                Console.WriteLine($"요청 정보 - 닉네임: {gamenickname}, 게임타입: {gametype}, 게임수: {count}");

                #region 데이터베이스에서 매치 조회
                List<Match> temp = new List<Match>();

                if(string.IsNullOrEmpty(gametype) || gametype == "All")
                {
                    try
                    {
                        using (var context = new MatchContext())
                        {
                            var matches = context.Matches
                                .Include("participants")
                                .Include("participants.Tiers")
                                .Include("teams")
                                .Where(m => m.GameNickName == gamenickname)
                                .OrderByDescending(m => m._gameEndTimestamp)  // 최신 순으로 정렬
                                .Take(count)
                                .ToList();

                            temp.AddRange(matches);
                            Console.WriteLine($"찾은 매치 수: {temp.Count}");
                        }
                    }
                    catch (Exception dbEx)
                    {
                        Console.WriteLine($"DB 조회 오류: {dbEx.Message}");
                        Console.WriteLine($"스택 트레이스: {dbEx.StackTrace}");
                    }
                }
                else if(gametype == "ranked")
                {
                    try
                    {
                        using (var context = new MatchContext())
                        {
                            var matches = context.Matches
                                .Include("participants")
                                .Include("participants.Tiers")
                                .Include("teams")
                                .Where(m => m.GameNickName == gamenickname)
                                .Where(m => m._queueId.Contains(gametype))
                                .OrderByDescending(m => m._gameEndTimestamp)  // 최신 순으로 정렬
                                .Take(count)
                                .ToList();

                            temp.AddRange(matches);
                            Console.WriteLine($"찾은 매치 수: {temp.Count}");
                        }
                    }
                    catch (Exception dbEx)
                    {
                        Console.WriteLine($"DB 조회 오류: {dbEx.Message}");
                        Console.WriteLine($"스택 트레이스: {dbEx.StackTrace}");
                    }
                }
                else
                {
                    try
                    {
                        using (var context = new MatchContext())
                        {
                            var matches = context.Matches
                                .Include("participants")
                                .Include("participants.Tiers")
                                .Include("teams")
                                .Where(m => m.GameNickName == gamenickname)
                                .Where(m => (m._queueId == "칼바람" || m._queueId == "일반"))
                                .OrderByDescending(m => m._gameEndTimestamp)  // 최신 순으로 정렬
                                .Take(count)
                                .ToList();

                            temp.AddRange(matches);
                            Console.WriteLine($"찾은 매치 수: {temp.Count}");
                        }
                    }
                    catch (Exception dbEx)
                    {
                        Console.WriteLine($"DB 조회 오류: {dbEx.Message}");
                        Console.WriteLine($"스택 트레이스: {dbEx.StackTrace}");
                    }
                }


                var response = new GameListResponse
                {
                    RequestMatchJson = JsonConvert.SerializeObject(temp)
                };

                Console.WriteLine($"반환할 게임 개수: {temp.Count}");
                return response;
                #endregion
            }
            catch (Exception ex)
            {
                Console.WriteLine($"GetGameHistory 오류: {ex.Message}");
                Console.WriteLine($"스택 트레이스: {ex.StackTrace}");
                return null;
            }
            
        }

        #endregion
    }
}