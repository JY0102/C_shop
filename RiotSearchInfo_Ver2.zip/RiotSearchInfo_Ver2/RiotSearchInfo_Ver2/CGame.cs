﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.ServiceModel.Web;
using System.Data.Entity;
using System.IO;
using Newtonsoft.Json;
using System.Text;
using System.Text.RegularExpressions;

namespace RiotSearchInfo_Ver2
{
    internal class CGame : IGame
    {
        private readonly OpenAPI _openAPI;
        private const string API_KEY = "RGAPI-dd01aece-2772-4a6e-a3bd-252c647ea6f4";

        public CGame()
        {
            try
            {
                Console.WriteLine("CGame 초기화 시작...");
                _openAPI = new OpenAPI();
                _openAPI.AddKey(API_KEY);
                Console.WriteLine("CGame 초기화 완료");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"CGame 초기화 실패: {ex.Message}");
                throw new Exception($"CGame 초기화 중 오류 발생: {ex.Message}");
            }
        }

        #region Public Methods - GET
        public GameListResponse SearchGameInfo(string gamenickname, string gametype, string gamecount)
        {
            try
            {
                Console.WriteLine("SearchGameInfo 호출됨");

                Console.WriteLine($"요청 정보 - 닉네임: {gamenickname}, 게임타입: {gametype}, 게임수: {gamecount}");

                if (string.IsNullOrEmpty(gamenickname))
                {
                    Console.WriteLine("Game nickname is empty");
                }

                if (!gamenickname.Contains("#"))
                {
                    Console.WriteLine("Invalid nickname format");
                }

                int count = int.Parse(gamecount); 
                if (!string.IsNullOrEmpty(gamecount))
                {
                    if (int.TryParse(gamecount, out int parsedCount))
                    {
                        count = Math.Max(1, Math.Min(parsedCount, 20));
                        Console.WriteLine($"요청된 게임 수: {parsedCount}, 실제 조회 수: {count}");
                    }
                    else
                    {
                        Console.WriteLine($"잘못된 게임 수 형식: {gamecount}, 기본값 사용");
                    }
                }

                #region API를 통한 Match Search 및 DB 저장
                Console.WriteLine($"매치 검색 시작... (최근 {count}게임)");
                List<Match> matches = _openAPI.Search(gamenickname, gametype, count);

                if (matches == null || matches.Count == 0)
                {
                    Console.WriteLine("매치를 찾을 수 없음");
                }

                Console.WriteLine($"매치 검색 완료: {count}개 찾음");
                #endregion

                var response = new GameListResponse
                {
                    RequestMatchJson = JsonConvert.SerializeObject(matches)
                };

                Console.WriteLine($"반환할 게임 개수: {matches.Count}");
                return response;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"SearchGameInfo 오류: {ex.Message}");
                Console.WriteLine($"스택 트레이스: {ex.StackTrace}");
                return null;
            }
        }
        #endregion
    }
}