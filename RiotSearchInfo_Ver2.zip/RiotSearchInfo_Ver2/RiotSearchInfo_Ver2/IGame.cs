﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;

//IGame.cs
namespace RiotSearchInfo_Ver2
{
    #region Request DTO
    [DataContract]
    public class SearchGameInfoRequest
    {
        [DataMember]
        public string gamenickname { get; set; }

        [DataMember]
        public string gametype { get; set; }

        [DataMember]
        public string gamecount { get; set; }
    }

    [DataContract]
    public class GameListResponse
    {
        [DataMember]
        public string RequestMatchJson {  get; set; }
    }
    #endregion

    #region Service Contract
    [ServiceContract]
    public interface IGame
    {
        // GET 요청 - 저장된 데이터 순회 후 반환
        [OperationContract]
        [WebGet(ResponseFormat = WebMessageFormat.Json,
                UriTemplate = "GetGameHistory?gamenickname={gamenickname}&gametype={gametype}&gamecount={gamecount}")]
        GameListResponse SearchGameInfo(string gamenickname, string gametype, string gamecount);
    }
    #endregion
}