﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace RiotSearchInfo_Ver2
{
    public class RiotTable : DataDragon
    {
        public RiotTable()
        {
            try
            {
                if (InItDirectory())
                {
                    GetSpellImg(base.DD_VERSION);

                    GetRuneImg(base.DD_VERSION);

                    GetItemImg(base.DD_VERSION);

                    GetChampionImg(base.DD_VERSION);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"이미지 다운로드 중 오류: {ex.Message}");
            }
        }

        #region 폴더 생성 및 딕셔너리 설정

        private enum FileName
        {
            Spell_Img,
            Rune_Img,
            Champion_Img,
            Item_Img
        }

        private const string PATH = @"C:\Riot_Img\";

        public bool InItDirectory()
        {
            string folderPath = PATH;

            // 메인 폴더가 존재하지 않으면 새로 생성
            if (Directory.Exists(folderPath))
            {
                return false;
            }

            Directory.CreateDirectory(folderPath);

            // 각 서브 폴더 생성
            foreach (var name in Enum.GetNames(typeof(FileName)))
            {
                folderPath = PATH + name;

                // 폴더가 존재하지 않으면 새로 생성
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                    Console.WriteLine($"폴더 생성: {folderPath}");
                }
            }

            return true;
        }

        #endregion

        #region ROW 값 추가

        internal void GetRuneImg(string version)
        {
            string url = $"https://ddragon.leagueoflegends.com/cdn/{version}/data/ko_KR/runesReforged.json";

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();

            if (response.StatusCode != HttpStatusCode.OK)
                throw new Exception($"{response.StatusCode}");

            // 응답 본문 읽기
            using (Stream stream = response.GetResponseStream())
            {
                using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
                {
                    string responseText = reader.ReadToEnd();

                    var runes = JsonConvert.DeserializeObject<List<RuneData>>(responseText);

                    SetRuneDirectory(runes);
                }
            }
        }

        internal void SetRuneDirectory(List<RuneData> ruenDatas)
        {
            foreach (var rune in ruenDatas)
            {
                GetRuneUrl(rune.id, rune.icon);

                foreach (var slot in rune.slots)
                {
                    foreach (var runes in slot["runes"])
                    {
                        GetRuneUrl(runes.id, runes.icon);
                    }
                }
            }
        }

        internal void GetSpellImg(string version)
        {
            string url = $"https://ddragon.leagueoflegends.com/cdn/{version}/data/ko_KR/summoner.json";

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();

            if (response.StatusCode != HttpStatusCode.OK)
                throw new Exception($"{response.StatusCode}");

            // 응답 본문 읽기
            using (Stream stream = response.GetResponseStream())
            {
                using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
                {
                    string responseText = reader.ReadToEnd();

                    var spellData = JsonConvert.DeserializeObject<SpellData>(responseText);

                    SetSpellDirectory(spellData);
                }
            }
        }

        internal void SetSpellDirectory(SpellData spellData)
        {
            foreach (var spell in spellData.Data)
            {
                GetSpellUrl(spell.Value.key, spell.Key);
            }
        }

        internal void GetItemImg(string version)
        {
            string url = $"https://ddragon.leagueoflegends.com/cdn/{version}/data/ko_KR/item.json";

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();

            if (response.StatusCode != HttpStatusCode.OK)
                throw new Exception($"{response.StatusCode}");

            // 응답 본문 읽기
            using (Stream stream = response.GetResponseStream())
            {
                List<Item> items = new List<Item>();

                using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
                {
                    string responseText = reader.ReadToEnd();
                    var data = JsonConvert.DeserializeObject<ItemData>(responseText);

                    foreach (var temp in data.Data)
                    {
                        temp.Value.Id = temp.Key;
                    }

                    SetItemDirectory(data);
                }
            }
        }

        internal void SetItemDirectory(ItemData items)
        {
            foreach (var item in items.Data)
            {
                GetItemUrl(item.Value.img);
            }
        }

        internal void GetChampionImg(string version)
        {
            try
            {
                string url = $"https://ddragon.leagueoflegends.com/cdn/{version}/data/ko_KR/champion.json";

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);

                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    if (response.StatusCode != HttpStatusCode.OK)
                    {
                        Console.WriteLine($"챔피언 데이터 요청 실패: {response.StatusCode}");
                        return;
                    }

                    // 응답 본문 읽기
                    using (Stream stream = response.GetResponseStream())
                    using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
                    {
                        string responseText = reader.ReadToEnd();
                        var champion = JsonConvert.DeserializeObject<Champion>(responseText);

                        if (champion?.Data != null)
                        {
                            SetChampionDirectory(champion);
                            //Console.WriteLine($"챔피언 이미지 다운로드 완료: {champion.Data.Count}개");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"GetChampionImg 오류: {ex.Message}");
            }
        }

        internal void SetChampionDirectory(Champion champion)
        {
            if (champion?.Data == null) return;

            foreach (var temp in champion.Data)
            {
                try
                {
                    string filePath = $@"{PATH}Champion_Img\{temp.Key}.png";
                    if (!File.Exists(filePath))
                    {
                        GetChampionUrl(temp.Key);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"챔피언 이미지 처리 오류 ({temp.Key}): {ex.Message}");
                }
            }
        }

        #endregion

        #region 데이터 테이블 -> 절대경로 -> Byte

        public byte[] GetSpellByte(string spellNum)
        {
            try
            {
                if (string.IsNullOrEmpty(spellNum) || spellNum == "0") return null;

                string filePath = $@"{PATH}Spell_Img\{spellNum}.png";

                if (!File.Exists(filePath))
                {
                    Console.WriteLine($"스펠 이미지 파일이 존재하지 않음: {filePath}");
                    return null;
                }

                using (FileStream picFileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    BinaryReader picReader = new BinaryReader(picFileStream);
                    return picReader.ReadBytes(Convert.ToInt32(picFileStream.Length));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"스펠 이미지 불러오기 오류 ({spellNum}): {ex.Message}");
                return null;
            }
        }

        public byte[] GetRuneByte(string Rune_Num)
        {
            try
            {
                if (string.IsNullOrEmpty(Rune_Num) || Rune_Num == "0") return null;

                string filePath = $@"{PATH}Rune_Img\{Rune_Num}.png";

                if (!File.Exists(filePath))
                {
                    Console.WriteLine($"룬 이미지 파일이 존재하지 않음: {filePath}");
                    return null;
                }

                using (FileStream picFileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    BinaryReader picReader = new BinaryReader(picFileStream);
                    return picReader.ReadBytes(Convert.ToInt32(picFileStream.Length));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"룬 이미지 불러오기 오류 ({Rune_Num}): {ex.Message}");
                return null;
            }
        }

        public byte[] GetChampionByte(string Champion_Name)
        {
            try
            {
                if (string.IsNullOrEmpty(Champion_Name)) return null;

                string filePath = $@"{PATH}Champion_Img\{Champion_Name}.png";

                if (!File.Exists(filePath))
                {
                    Console.WriteLine($"챔피언 이미지 파일이 존재하지 않음: {filePath}");
                    return null;
                }

                using (FileStream picFileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    BinaryReader picReader = new BinaryReader(picFileStream);
                    return picReader.ReadBytes(Convert.ToInt32(picFileStream.Length));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"챔피언 이미지 불러오기 오류 ({Champion_Name}): {ex.Message}");
                return null;
            }
        }

        public byte[] GetItemByte(string itemNum)
        {
            try
            {
                if (string.IsNullOrEmpty(itemNum) || itemNum == "0")
                    itemNum = "7050";

                string filePath = $@"{PATH}Item_Img\{itemNum}.png";

                if (!File.Exists(filePath))
                {
                    Console.WriteLine($"아이템 이미지 파일이 존재하지 않음: {filePath}");
                    return null;
                }

                using (FileStream picFileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    BinaryReader picReader = new BinaryReader(picFileStream);
                    return picReader.ReadBytes(Convert.ToInt32(picFileStream.Length));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"아이템 이미지 불러오기 오류 ({itemNum}): {ex.Message}");
                return null;
            }
        }

        #endregion
    }

}
