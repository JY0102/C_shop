﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Runtime.Serialization;

namespace RiotSearchInfo_Ver2
{
    [DataContract]
    public class Match
    {
        [DataMember]
        [Key]
        public string matchId { get; set; }

        [DataMember]
        public string GameNickName { get; set; }

        #region 매치 정보

        [DataMember] public string _queueId { get; set; }
        [DataMember]
        public string queueId
        {
            get => _queueId;
            set
            {
                switch (value)
                {
                    case "420": _queueId = "솔로랭크"; break;
                    case "440": _queueId = "자유랭크"; break;
                    case "400": _queueId = "일반"; break;
                    case "450": _queueId = "칼바람"; break;
                    default: _queueId = value; break;
                }
            }
        }

        [DataMember] public DateTime _gameEndTimestamp { get; set; }

        [DataMember]
        public string gameEndTimestamp
        {
            get => _gameEndTimestamp.ToString();
            set
            {
                long timestamp;

                if (long.TryParse(value.ToString(), out timestamp))
                {
                    DateTimeOffset dateTimeOffset = DateTimeOffset.FromUnixTimeMilliseconds(timestamp);
                    _gameEndTimestamp = dateTimeOffset.LocalDateTime;
                }
                else
                {
                    _gameEndTimestamp = DateTime.Parse(value);
                }
            }
        }

        #endregion

        #region 팀 정보
        [DataMember]
        public virtual List<Team> teams { get; set; }

        // NotMapped 속성으로 설정하여 데이터베이스 컬럼에 저장하지 않도록 함
        [DataMember]
        [NotMapped]
        public Team blueTeam { get => teams?[0]; }

        [DataMember]
        [NotMapped]
        public Team redTeam { get => teams?.Count > 1 ? teams[1] : null; }
        #endregion

        #region 참가자들
        [DataMember]
        public virtual List<Participant> participants { get; set; }
        #endregion

        #region 나의 전적

        [DataMember] public int idx { get; set; } = -1;
        [DataMember]
        public Participant MyPart
        {
            get
            {
                if (idx != -1 && participants?.Count > idx)
                    return participants[idx];
                return null;
            }
        }
        public void SetMyPart(string puuid)
        {
            if (participants == null || string.IsNullOrEmpty(puuid)) return;

            for (int i = 0; i < participants.Count && i < 10; i++)
            {
                if (participants[i] == null) continue;

                if (participants[i].puuid == puuid)
                    idx = i;

                try
                {
                    if (i < 5 && blueTeam != null)
                    {
                        if (decimal.TryParse(blueTeam.champion ?? "0", out decimal teamkill) &&
                            decimal.TryParse(participants[i].kills ?? "0", out decimal kills) &&
                            decimal.TryParse(participants[i].assists ?? "0", out decimal assist))
                        {
                            decimal percent = (teamkill <= 0) ? 0 : (kills + assist) / teamkill;
                            participants[i].killPercent = $"{percent:P0}";
                        }
                    }
                    else if (i >= 5 && redTeam != null)
                    {
                        if (decimal.TryParse(redTeam.champion ?? "0", out decimal teamkill) &&
                            decimal.TryParse(participants[i].kills ?? "0", out decimal kills) &&
                            decimal.TryParse(participants[i].assists ?? "0", out decimal assist))
                        {
                            decimal percent = (teamkill <= 0) ? 0 : (kills + assist) / teamkill;
                            participants[i].killPercent = $"{percent:P0}";
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"킬 퍼센트 계산 오류: {ex.Message}");
                    participants[i].killPercent = "0%";
                }
            }
        }

        #endregion
    }
}
