﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace RiotSearchInfo_Ver2
{
    public class DataDragon
    {
        internal string DD_VERSION = "";

        public DataDragon()
        {
            InItDataDragonVersion();
        }


        #region 데이터 드래곤 버전 설정

        public void InItDataDragonVersion()
        {
            try
            {
                string url = $"https://ddragon.leagueoflegends.com/api/versions.json";

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);

                HttpWebResponse response = (HttpWebResponse)request.GetResponse();

                if (response.StatusCode != HttpStatusCode.OK)
                {
                    throw new Exception($"{response.StatusCode}");
                }

                // 응답 본문 읽기
                using (Stream stream = response.GetResponseStream())
                {
                    using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
                    {
                        string responseText = reader.ReadToEnd();

                        var version = JsonConvert.DeserializeObject<List<string>>(responseText);
                        DD_VERSION = version[0];
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error : " + ex.Message);
            }
        }

        #endregion

        #region 이미지 절대 경로에 다운로드

        public void GetItemUrl(string itemNum)
        {
            string url = $"https://ddragon.leagueoflegends.com/cdn/{DD_VERSION}/img/item/{itemNum}";

            using (WebClient client = new WebClient())
            {
                try
                {
                    byte[] imageBytes = client.DownloadData(url);
                    string folderPath = @"C:\Riot_Img\Item_Img";

                    if (!Directory.Exists(folderPath))
                    {
                        Directory.CreateDirectory(folderPath);
                    }

                    string fileName = $"{itemNum}";
                    string fullPath = Path.Combine(folderPath, fileName);

                    // 파일이 이미 존재하면 건너뛰기
                    if (!File.Exists(fullPath))
                    {
                        File.WriteAllBytes(fullPath, imageBytes);
                    }
                }
                catch (WebException ex)
                {
                    Console.WriteLine($"GetItemUrl 네트워크 오류: {ex.Message}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"GetItemUrl 오류 발생: {ex.Message}");
                }
            }
        }

        public void GetChampionUrl(string championName)
        {
            if (string.IsNullOrEmpty(championName))
            {
                Console.WriteLine("Champion name is null or empty");
                return;
            }

            string url = $"https://ddragon.leagueoflegends.com/cdn/{DD_VERSION}/img/champion/{championName}.png";

            using (WebClient client = new WebClient())
            {
                try
                {
                    byte[] imageBytes = client.DownloadData(url);
                    string folderPath = @"C:\Riot_Img\Champion_Img";

                    // 폴더 존재 확인 및 생성
                    if (!Directory.Exists(folderPath))
                    {
                        Directory.CreateDirectory(folderPath);
                    }

                    string fileName = $"{championName}.png";
                    string fullPath = Path.Combine(folderPath, fileName);

                    File.WriteAllBytes(fullPath, imageBytes);
                    Console.WriteLine($"챔피언 이미지 저장 완료: {championName}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"GetChampionUrl 오류 발생 ({championName}): {ex.Message}");
                }
            }
        }

        public void GetSpellUrl(string id, string SpellName)
        {

            string url = $"https://ddragon.leagueoflegends.com/cdn/{DD_VERSION}/img/spell/{SpellName}.png";

            using (WebClient client = new WebClient())
            {
                try
                {
                    byte[] imageBytes = client.DownloadData(url);   // 이미지 바이트 배열
                    string folderPath = @"C:\Riot_Img\Spell_Img";   // 저장할 경로
                    string fileName = $"{id}.png";                  // 파일 이름

                    string fullPath = Path.Combine(folderPath, fileName);
                    File.WriteAllBytes(fullPath, imageBytes);
                }
                catch (Exception ex)
                {
                    throw new Exception($"GetSpellUrl 오류 발생: {ex.Message}");
                }
            }
        }

        public void GetRuneUrl(string runeId, string runeName)
        {
            string url = $"https://ddragon.leagueoflegends.com/cdn/img/{runeName}";

            using (WebClient client = new WebClient())
            {
                try
                {
                    byte[] imageBytes = client.DownloadData(url);   // 이미지 바이트 배열
                    string folderPath = @"C:\Riot_Img\Rune_Img";    // 저장할 경로
                    string fileName = $"{runeId}.png";              // 파일 이름

                    string fullPath = Path.Combine(folderPath, fileName);
                    File.WriteAllBytes(fullPath, imageBytes);
                }
                catch (Exception ex)
                {
                    throw new Exception($"GetRuneUrl 오류 발생: {ex.Message}");
                }
            }
        }

        #endregion
    }
}
