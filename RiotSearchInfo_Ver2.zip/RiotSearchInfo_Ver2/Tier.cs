﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace RiotSearchInfo_Ver2
{
    [DataContract]
    public class Tier
    {
        #region 데이터 테이블 PK , FK 설정

        public int ParticipantId { get; set; }

        [ForeignKey("ParticipantId")]
        public virtual Participant Participant { get; set; }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int TierId { get; set; }

        #endregion


        [DataMember] private string _queueType;
        [DataMember]
        public string queueType
        {
            get => _queueType;
            set
            {
                if (value == null) return;

                switch (value)
                {
                    case "RANKED_SOLO_5x5":
                        _queueType = "솔로랭크";
                        break;
                    case "RANKED_FLEX_SR":
                        _queueType = "자유랭크";
                        break;
                    default:
                        _queueType = value;
                        break;
                }
            }
        }
        [DataMember] public string TierInfo { get => $"{tier} {rank}"; }
        [DataMember] public string tier { get; set; }
        [DataMember] public string rank { get; set; }
        [DataMember] public string wins { get; set; }
        [DataMember] public string losses { get; set; }
    }
}
