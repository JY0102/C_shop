﻿//App.cs
using System;
using System.Net.Sockets;
using System.Threading;
using WoosongBit41.ClientNet;
using WoosongBit41.Lib;
using WoosongBit41.Packet;
using WoosongBit41.UI;


namespace _0410_채팅클라이언트
{
    internal class App
    {
        //private const string SERVER_IP = "220.90.180.111";
        private const string SERVER_IP = "220.90.180.96";
        private const int SERVER_PORT   = 7000;

        #region 0. 싱글톤 패턴
        public static App Singleton { get; } = null;
        static App() { Singleton = new App(); }
        private App() {}
        #endregion

        #region 1. CallBack Message

        public static void LogMessage(Socket sock, string message)
        {
            Console.WriteLine($"[log] {message}");
        }
        public static void PacketMessage(Socket sock, string message)
        {
            //2. 패킷 파싱(분석)
            string[] sp = message.Split('@');

            //3. 분석 분할 처리
            switch (int.Parse(sp[0]))
            {
                case Packet.PACKET_INSERTUSER_ACK:      Packet.InsertUserAck(sp[1]);      break;
                case Packet.PACKET_LOGINUSER_ACK:       Packet.LoginUserAck(sp[1]);       break;
                case Packet.PACKET_FINDUSER_ACK:        Packet.FindUserAck(sp[1]);        break;
                case Packet.PACKET_CALLUSER:            CallAckUser.Invoke(sp[1]);        break;
                case Packet.PACKET_SENDMESSAGEUSER_ACK: Packet.SendMessageUserAck(sp[1]); break;
                case Packet.PACKET_EXITUSER_ACK:        Packet.ExitUserAck(sp[1]);        break;
                case Packet.PACKET_SENDALLUSER_ACK:     Packet.SendAllUserAck(sp[1]);     break;
                case Packet.PACKET_DELETEUSER_ACK:      Packet.DeleteUserAck(sp[1]);      break;
                default:   Console.WriteLine("없는 flag 입니다");    break;
            }
        }
        #endregion

        #region 2. 시작 , 실행 , 종료
        public void Init()
        {

            MyClient.Singleton.Start(SERVER_IP , SERVER_PORT , LogMessage , PacketMessage);
            UserControl.Singleton.Init();

            WbLib.Logo();
        }
        public void Run()
        {
            while(true)
            {
                First();

                Second();
            }
        }
        public void First()
        {
            while (MyClient.MyLogin.Name == null)
            {
                Console.Clear();
                switch (WbLib.First_Screen())
                {
                    case ConsoleKey.Escape: return;
                    case ConsoleKey.F1: InsertUser.Invoke(); break; // 회원가입
                    case ConsoleKey.F2: LoginUser.Invoke(); break; // 로그인
                    case ConsoleKey.F3: DeleteUser.Invoke(); break; // 회원탈퇴
                    case ConsoleKey.F9: break;
                    case ConsoleKey.F10: break;
                    default: Console.WriteLine("잘못 입력하셨습니다."); break;

                }
                Thread.Sleep(30);
                WbLib.Pause();
            }
        }
        public void Second()
        {
            while (true)
            {
                Console.Clear();
                switch (WbLib.Second_Screed())
                {
                    case ConsoleKey.Escape: return;
                    case ConsoleKey.F1: FindUser.Invoke(); break; // 통신 대상 찾기
                    case ConsoleKey.F9: break;
                    case ConsoleKey.F10:break;
                    default: Console.WriteLine("잘못 입력하셨습니다."); break;
                }
                WbLib.Pause();
            }
        }
        public void Exit()
        {
            UserControl.Singleton.Exit();
            WbLib.Ending();
        }
        #endregion
    }
}
