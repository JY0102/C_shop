﻿//WbLib.cs
using System;
using WoosongBit41.ClientNet;
using WoosongBit41.Data;

namespace WoosongBit41.Lib
{
    internal static class WbLib
    {
        #region 1. 로고, 메뉴, 종료출력 메시지
        public static void Pause()
        {
            Console.ReadKey(true);
        }

        public static void Logo()
        {
            Console.Clear();
            Console.WriteLine("*************************************************************************");
            Console.WriteLine(" 2025년 2학기 우송비트고급41기");
            Console.WriteLine(" C#언어");
            Console.WriteLine(" 채팅 프로그램");
            Console.WriteLine(" 2025-04-10");
            Console.WriteLine(" ccm");
            Console.WriteLine("*************************************************************************");
            Pause();
        }
        public static ConsoleKey First_Screen()
        {
            Console.Clear();
            Console.WriteLine("*************************************************************************");
            Console.WriteLine("[ESC] 프로그램 종료");
            Console.WriteLine("[F1] 회원가입 ");
            Console.WriteLine("[F2] 로그인");
            Console.WriteLine("[F3] 회원 탈퇴");
            Console.WriteLine("*************************************************************************");
            return Console.ReadKey().Key;
        }
        public static ConsoleKey Second_Screed()
        {
            Console.WriteLine("*************************************************************************");
            Console.WriteLine("이름 : {0}",  (MyClient.MyLogin.Name?? "로그인이 안됐습니다.") );
            Console.WriteLine("[ESC] 프로그램 종료");
            Console.WriteLine("[F1]  상대방 탐색");
            Console.WriteLine("[F2]  메세지 전송");
            Console.WriteLine("*************************************************************************");
            return Console.ReadKey().Key;
        }
        public static ConsoleKey Third_Screed()
        {
            Console.WriteLine("*************************************************************************");
            Console.WriteLine("[ESC] 채팅방 나가기");
            Console.WriteLine(" /공지사항  + MSG -> 전체메세지 전송");
            Console.WriteLine("*************************************************************************");
            return Console.ReadKey().Key;
        }


        public static void Ending()
        {
            Console.Clear();
            Console.WriteLine("*************************************************************************");
            Console.WriteLine(" 프로그램을 종료합니다.");
            Console.WriteLine("*************************************************************************");
            Pause();
        }
        #endregion

        #region 2. 입력
        public static int InputInteger(string msg)
        {
            Console.Write(msg + " : ");
            return int.Parse(Console.ReadLine());
        }

        public static float InputFloat(string msg)
        {
            Console.Write(msg + " : ");
            return float.Parse(Console.ReadLine());
        }
        public static bool InputBool(string msg)
        {
            Console.WriteLine(msg + ":");
            return TrueOrFalse();
        }
        public static char InputChar(string msg)
        {
            Console.Write(msg + " : ");
            return char.Parse(Console.ReadLine());
        }

        public static string InputString(string msg)
        {
            Console.Write(msg + " : ");
            return Console.ReadLine();
        }



        private static bool TrueOrFalse()
        {
            ConsoleKeyInfo flag = new ConsoleKeyInfo();
            while (true)
            {
                Console.WriteLine("\n\n");
                Console.WriteLine("[F9] 예 ");
                Console.WriteLine("[F10] 아니요");
                flag = Console.ReadKey();
                if (flag.Key == ConsoleKey.F9 || flag.Key == ConsoleKey.F10) break;
            }
            return flag.Key == ConsoleKey.F9;
        }
        #endregion

        #region 3. 날짜와 시간을 문자열로 반환
        public static string Get_Date(DateTime time)
        {
            return string.Format("{0}-{1}-{2}", time.Year, time.Month, time.Day);
        }
        public static string Get_Time(DateTime time)
        {
            return string.Format("{0}:{1}:{2}", time.Hour, time.Minute, time.Second);
        }
        #endregion
    }
}
