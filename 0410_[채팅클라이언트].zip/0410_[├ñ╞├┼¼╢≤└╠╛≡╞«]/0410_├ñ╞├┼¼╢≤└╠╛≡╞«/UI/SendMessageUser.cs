﻿using _0410_채팅클라이언트;
using System;
using WoosongBit41.Lib;

namespace WoosongBit41.UI
{
    internal static class SendMessageUser
    {
        public static void Invoke()
        {
            try
            {
                string msg = WbLib.InputString("메세지 내용 입력");

                UserControl con = UserControl.Singleton;
                con.UserSendMessage(msg);
            }
            catch (Exception ex)
            {
                Console.WriteLine("[SendMessage ERROR ] : " + ex.Message);
            }
        }
    }
}
