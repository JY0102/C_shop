﻿using _0410_채팅클라이언트;
using System;
using WoosongBit41.Lib;

namespace WoosongBit41.UI
{
    internal static class SendAllUser
    {
        public static void Invoke()
        {
            //Console.WriteLine("\n[공지사항 보내기]\n");
            try
            {
                string message = WbLib.InputString(" 공지사항으로 보낼 메세지 ");

                UserControl con = UserControl.Singleton;
                con.UserSendAll(message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("[SendAll ERROR ] : " + ex.Message);
            }
        }
    }
}
